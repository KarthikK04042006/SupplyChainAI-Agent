package com.supplychain.ai.service;

import com.supplychain.ai.dto.AnalyticsSummaryDto;
import com.supplychain.ai.model.SupplyChainData;
import com.supplychain.ai.repository.SupplyChainDataRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AnalyticsService {

    private final SupplyChainDataRepository dataRepository;

    public AnalyticsService(SupplyChainDataRepository dataRepository) {
        this.dataRepository = dataRepository;
    }

    public AnalyticsSummaryDto getSummary() {
        List<SupplyChainData> allData = dataRepository.findAll();
        
        if (allData.isEmpty()) {
            return AnalyticsSummaryDto.builder()
                    .salesByRegion(new HashMap<>())
                    .salesByCategory(new HashMap<>())
                    .monthlySales(new LinkedHashMap<>())
                    .build();
        }

        double totalSales = allData.stream().mapToDouble(SupplyChainData::getSales).sum();
        double totalProfit = allData.stream().mapToDouble(SupplyChainData::getProfit).sum();
        int totalQuantity = allData.stream().mapToInt(SupplyChainData::getQuantity).sum();
        double totalShipping = allData.stream().mapToDouble(SupplyChainData::getShippingCost).sum();
        double totalDiscount = allData.stream().mapToDouble(SupplyChainData::getDiscount).sum();

        Map<String, Double> salesByRegion = allData.stream()
                .collect(Collectors.groupingBy(SupplyChainData::getRegion, 
                        Collectors.summingDouble(SupplyChainData::getSales)));

        Map<String, Double> salesByCategory = allData.stream()
                .collect(Collectors.groupingBy(SupplyChainData::getCategory, 
                        Collectors.summingDouble(SupplyChainData::getSales)));

        // Sort months chronologically
        Map<String, Double> monthlySales = allData.stream()
                .collect(Collectors.groupingBy(d -> d.getOrderDate().getMonth().toString(), 
                        LinkedHashMap::new,
                        Collectors.summingDouble(SupplyChainData::getSales)));

        Map<String, Double> topProducts = allData.stream()
                .collect(Collectors.groupingBy(SupplyChainData::getProductName, 
                        Collectors.summingDouble(SupplyChainData::getSales)))
                .entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(10)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        return AnalyticsSummaryDto.builder()
                .totalOrders(allData.size())
                .totalSales(totalSales)
                .avgSales(totalSales / allData.size())
                .totalProfit(totalProfit)
                .avgProfit(totalProfit / allData.size())
                .profitMargin((totalProfit / totalSales) * 100)
                .totalQuantity(totalQuantity)
                .totalShippingCost(totalShipping)
                .totalDiscount(totalDiscount)
                .salesByRegion(salesByRegion)
                .salesByCategory(salesByCategory)
                .monthlySales(monthlySales)
                .topProducts(topProducts)
                .salesGrowth(12.5) // Mocked for now
                .orderGrowth(8.2)   // Mocked for now
                .build();
    }
}
