package com.supplychain.ai.service;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.supplychain.ai.dto.AnalyticsSummaryDto;
import com.supplychain.ai.model.SupplyChainData;
import com.supplychain.ai.repository.SupplyChainDataRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ReportService {

    private final SupplyChainDataRepository dataRepository;
    private final AnalyticsService analyticsService;

    public ReportService(SupplyChainDataRepository dataRepository, AnalyticsService analyticsService) {
        this.dataRepository = dataRepository;
        this.analyticsService = analyticsService;
    }

    public ByteArrayInputStream generatePdfReport() throws IOException {
        AnalyticsSummaryDto summary = analyticsService.getSummary();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("Supply Chain AI Agent - Executive Summary").setFontSize(20).setBold());
        document.add(new Paragraph("Total Sales: $" + summary.getTotalSales()));
        document.add(new Paragraph("Total Profit: $" + summary.getTotalProfit()));
        document.add(new Paragraph("Total Orders: " + summary.getTotalOrders()));
        document.add(new Paragraph("Profit Margin: " + String.format("%.2f", summary.getProfitMargin()) + "%"));

        document.close();
        return new ByteArrayInputStream(out.toByteArray());
    }

    public ByteArrayInputStream generateExcelReport() throws IOException {
        List<SupplyChainData> data = dataRepository.findAll();
        
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Supply Chain Data");

            Row headerRow = sheet.createRow(0);
            String[] columns = {"Order ID", "Order Date", "Customer Name", "Region", "Category", "Sales", "Profit"};
            for (int i = 0; i < columns.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
            }

            int rowIdx = 1;
            for (SupplyChainData item : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(item.getOrderId());
                row.createCell(1).setCellValue(item.getOrderDate().toString());
                row.createCell(2).setCellValue(item.getCustomerName());
                row.createCell(3).setCellValue(item.getRegion());
                row.createCell(4).setCellValue(item.getCategory());
                row.createCell(5).setCellValue(item.getSales());
                row.createCell(6).setCellValue(item.getProfit());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }
}
