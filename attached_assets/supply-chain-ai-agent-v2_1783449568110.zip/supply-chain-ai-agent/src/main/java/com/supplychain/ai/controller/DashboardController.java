package com.supplychain.ai.controller;

import com.supplychain.ai.service.AnalyticsService;
import com.supplychain.ai.service.UploadHistoryRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final AnalyticsService analyticsService;
    private final UploadHistoryRepository uploadRepository;

    public DashboardController(AnalyticsService analyticsService, UploadHistoryRepository uploadRepository) {
        this.analyticsService = analyticsService;
        this.uploadRepository = uploadRepository;
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("summary", analyticsService.getSummary());
        model.addAttribute("recentUploads", uploadRepository.findAllByOrderByUploadTimeDesc().stream().limit(5).toList());
        return "dashboard/index";
    }
}
