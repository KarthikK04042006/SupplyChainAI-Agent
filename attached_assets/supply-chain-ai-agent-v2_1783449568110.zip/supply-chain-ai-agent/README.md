# Supply Chain AI Agent

## Project Overview

The **Supply Chain AI Agent** is an enterprise-grade web application designed to provide comprehensive analytics and AI-driven insights for supply chain management. Built with a modern tech stack, it offers features such as CSV data upload, interactive dashboards, AI predictions (demand forecast, inventory prediction, risk analysis), and robust user authentication. The project aims to deliver a production-quality solution that can serve as a real startup product.

## Features

### Authentication
- **Secure Login Page**: Beautifully designed login page with animated background and glassmorphism.
- **User Management**: Spring Security for authentication and authorization.
- **Features**: Password show/hide, Remember me, Forgot password, Input validation, Session management, Logout, Professional error messages.

### Upload Module
- **Beautiful Upload Dashboard**: Intuitive interface for data ingestion.
- **Drag & Drop CSV Upload**: Easy and efficient file upload.
- **Upload Progress Bar**: Visual feedback during upload.
- **File & CSV Validation**: Ensures data integrity.
- **Success Animation**: Engaging user experience.
- **Upload History**: Tracks all past uploads.

### CSV Analytics
- **Automated Column Detection**: Smart parsing of CSV files using OpenCSV.
- **Key Metrics Calculation**: Total Orders, Total Sales, Average Sales, Highest Sales, Lowest Sales, Sales by Region/Category/Segment, Orders per Region/Category, Top 10 Products, Top Customers, Monthly/Yearly Sales, Profit, Quantity, Discount, Shipping Cost.

### AI Dashboard
- **Attractive Executive Dashboard**: Modern UI with large KPI cards, animated counters, glassmorphism, and gradient themes.
- **UI Elements**: Dark Mode, Responsive Design, Animated Sidebar, Top Navigation, Notifications, User Profile, Search Bar, Recent Uploads.

### Charts
- **Interactive Visualizations**: Bar Chart, Line Chart, Area Chart, Pie Chart, Donut Chart, Radar Chart, Scatter Plot, Heat Map, Trend Line.
- **Animated Charts**: Enhances user engagement.

### Filters
- **Dynamic Data Filtering**: By Region, Category, Segment, Year, Month, Sales Range, Product, Customer.

### AI Features
- **Predictive Analytics**: Demand Forecast, Inventory Prediction, Low Stock Prediction, Sales Forecast, Future Revenue Prediction.
- **Risk Management**: Risk Analysis, Supply Chain Health Score.
- **Smart Recommendations**: Best Selling Products Prediction, Slow Moving Inventory Prediction, Anomaly Detection.
- **Automated Insights Generation**.

### Reports
- **Export Options**: Generate PDF Report, Generate Excel Report.
- **Dashboard Management**: Download Dashboard, Print Dashboard.

### Profile Page
- **User Profile Management**: View and edit personal information.
- **Security**: Change Password.
- **Activity History**: Track user actions.

### Settings Page
- **Customization**: Theme (Dark Mode), Notification Settings, Language.

### Admin Features
- **User & Role Management**: Comprehensive control over user access.
- **Logging**: Audit Logs, Upload History, System Logs.

## Tech Stack

### Backend
- **Java 21**: Latest LTS version for robust applications.
- **Spring Boot 3**: Rapid application development framework.
- **Maven**: Dependency management and build automation.
- **Spring MVC**: Model-View-Controller architecture for web applications.
- **Spring Security**: Authentication and authorization framework.
- **Spring Data JPA**: Simplifies data access with Hibernate.
- **MySQL**: Relational database management system.
- **Thymeleaf**: Server-side Java template engine for web applications.
- **OpenCSV**: CSV parsing library.
- **Lombok**: Reduces boilerplate code.
- **REST APIs**: For inter-service communication and frontend interaction.

### Frontend
- **HTML5**: Structure of web pages.
- **CSS3**: Styling of web pages.
- **JavaScript (ES6)**: Interactive functionality.
- **Bootstrap 5**: Responsive design framework.
- **Chart.js**: For interactive charts.
- **Font Awesome**: Icon library.
- **AOS Animations**: Animate On Scroll library.
- **Animate.css**: Cross-browser library of CSS animations.

### Database
- **MySQL**

### Version Control
- **Git Ready**

## Project Structure

```
supply-chain-ai-agent/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── supplychain/
│   │   │           └── ai/
│   │   │               ├── controller/
│   │   │               ├── service/
│   │   │               ├── repository/
│   │   │               ├── model/
│   │   │               ├── dto/
│   │   │               ├── config/
│   │   │               ├── util/
│   │   │               └── exception/
│   │   └── resources/
│   │       ├── templates/
│   │       │   ├── auth/
│   │       │   ├── dashboard/
│   │       │   ├── upload/
│   │       │   ├── analytics/
│   │       │   ├── ai/
│   │       │   ├── reports/
│   │       │   ├── admin/
│   │       │   ├── profile/
│   │       │   └── settings/
│   │       ├── static/
│   │       │   ├── css/
│   │       │   ├── js/
│   │       │   ├── images/
│   │       │   ├── icons/
│   │       │   └── fonts/
│   │       └── application.properties
├── pom.xml
├── README.md
└── schema.sql
```

## Setup and Run

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd supply-chain-ai-agent
    ```

2.  **Database Setup:**
    - Ensure MySQL is running.
    - Execute the `schema.sql` file to create the database and tables:
    ```bash
    mysql -u root -p < schema.sql
    ```
    - Update `src/main/resources/application.properties` with your MySQL username and password.

3.  **Build the project:**
    ```bash
    mvn clean install
    ```

4.  **Run the application:**
    ```bash
    mvn spring-boot:run
    ```

5.  **Access the application:**
    Open your browser and navigate to `http://localhost:8080`.
    Default admin credentials: `username: admin`, `password: admin123`.

## UI Design Principles

-   **Premium SaaS Look**: Modern gradients, glassmorphism, smooth animations, hover effects, micro-interactions, loading animations, skeleton loading.
-   **Customization**: Custom icons, professional typography, rounded cards, soft shadows, professional color palette, excellent spacing.
-   **Responsiveness**: Fully responsive design for all devices.

## Animations

-   Fade In, Slide Up, Slide Left, Scale, Hover Lift, Animated Buttons, Card Animations, Page Transition, Loading Screen, Dashboard Counter Animation, Chart Animation.

## Quality Assurance

-   **Clean Code**: No duplicate code, adherence to SOLID principles, proper service layer implementation.
-   **Robustness**: Proper exception handling.
-   **Maintainability**: Comments only where necessary, professional naming conventions, clean architecture.

This project is designed to be interview-ready, production-quality, and suitable for showcasing on GitHub.
